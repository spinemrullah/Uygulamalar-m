package com.mycompany.myapp;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity {

    private GameView gameView;
    private Handler handler = new Handler();
    private final int HIZ = 150; // Milisaniye cinsinden hız

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Ana Düzen (Dikey)
        LinearLayout anaLayout = new LinearLayout(this);
        anaLayout.setOrientation(LinearLayout.VERTICAL);
        anaLayout.setBackgroundColor(Color.parseColor("#8BAB07")); // Nokia Yeşili Arkaplan

        // Oyun Ekranı
        gameView = new GameView(this);
        LinearLayout.LayoutParams gameParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        gameView.setLayoutParams(gameParams);
        anaLayout.addView(gameView);

        // Kontrol Paneli
        anaLayout.addView(createControllerLayout());

        setContentView(anaLayout);

        // Oyun Döngüsünü Başlat
        handler.postDelayed(gameLoop, HIZ);
    }

    private Runnable gameLoop = new Runnable() {
        @Override
        public void run() {
            if (!gameView.isGameOver) {
                gameView.update();
                gameView.invalidate();
                handler.postDelayed(this, HIZ);
            }
        }
    };

    // Butonları Oluşturma
    private View createControllerLayout() {
        LinearLayout cntrl = new LinearLayout(this);
        cntrl.setOrientation(LinearLayout.VERTICAL);
        cntrl.setGravity(Gravity.CENTER);
        cntrl.setPadding(20, 20, 20, 40);

        // Yukarı butonu
        cntrl.addView(makeBtn("YUKARI", "UP"));
        
        LinearLayout yatay = new LinearLayout(this);
        yatay.setGravity(Gravity.CENTER);
        yatay.addView(makeBtn("SOL", "LEFT"));
        yatay.addView(makeBtn("SAĞ", "RIGHT"));
        cntrl.addView(yatay);
        
        // Aşağı butonu
        cntrl.addView(makeBtn("AŞAĞI", "DOWN"));

        return cntrl;
    }

    private Button makeBtn(String text, final String dir) {
        Button b = new Button(this);
        b.setText(text);
        b.setBackgroundColor(Color.parseColor("#222222"));
        b.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(200, 120);
        p.setMargins(10, 10, 10, 10);
        b.setLayoutParams(p);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.setDirection(dir);
            }
        });
        return b;
    }

    // --- OYUN MANTIĞI VE ÇİZİM SINIFI ---
    class GameView extends View {
        private Paint paint = new Paint();
        private ArrayList<Point> snake = new ArrayList<>();
        private Point food;
        private String direction = "RIGHT";
        private int gridSize = 40;
        public boolean isGameOver = false;

        public GameView(Context context) {
            super(context);
            // Başlangıç yılanı (3 parça)
            snake.add(new Point(5, 5));
            snake.add(new Point(4, 5));
            snake.add(new Point(3, 5));
            spawnFood();
        }

        public void setDirection(String d) {
            // Zıt yöne gitmeyi engelle
            if (d.equals("UP") && !direction.equals("DOWN")) direction = "UP";
            if (d.equals("DOWN") && !direction.equals("UP")) direction = "DOWN";
            if (d.equals("LEFT") && !direction.equals("RIGHT")) direction = "LEFT";
            if (d.equals("RIGHT") && !direction.equals("LEFT")) direction = "RIGHT";
            if (isGameOver) restart();
        }

        private void spawnFood() {
            Random r = new Random();
            food = new Point(r.nextInt(15) + 1, r.nextInt(20) + 1);
        }

        private void restart() {
            snake.clear();
            snake.add(new Point(5, 5));
            snake.add(new Point(4, 5));
            direction = "RIGHT";
            isGameOver = false;
            spawnFood();
            handler.postDelayed(gameLoop, HIZ);
        }

        public void update() {
            Point head = snake.get(0);
            Point newHead = new Point(head.x, head.y);

            if (direction.equals("UP")) newHead.y--;
            if (direction.equals("DOWN")) newHead.y++;
            if (direction.equals("LEFT")) newHead.x--;
            if (direction.equals("RIGHT")) newHead.x++;

            // Çarpışma Kontrolü (Duvarlar)
            if (newHead.x < 0 || newHead.y < 0 || newHead.x >= getWidth()/gridSize || newHead.y >= getHeight()/gridSize) {
                isGameOver = true;
                return;
            }

            // Kendine çarpma kontrolü
            for (Point p : snake) {
                if (p.equals(newHead)) {
                    isGameOver = true;
                    return;
                }
            }

            snake.add(0, newHead);

            // Yemek yeme
            if (newHead.equals(food)) {
                spawnFood();
            } else {
                snake.remove(snake.size() - 1);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            
            // Yılanı Çiz (Siyah Kareler)
            paint.setColor(Color.parseColor("#222222"));
            for (Point p : snake) {
                canvas.drawRect(p.x * gridSize, p.y * gridSize, (p.x + 1) * gridSize - 2, (p.y + 1) * gridSize - 2, paint);
            }

            // Yemeği Çiz (Kırmızımtırak/Siyah Kare)
            paint.setColor(Color.BLACK);
            canvas.drawRect(food.x * gridSize, food.y * gridSize, (food.x + 1) * gridSize - 2, (food.y + 1) * gridSize - 2, paint);

            if (isGameOver) {
                paint.setColor(Color.BLACK);
                paint.setTextSize(60);
                canvas.drawText("OYUN BİTTİ!", 100, 200, paint);
                paint.setTextSize(40);
                canvas.drawText("Yön tuşuna basarak tekrar başla", 100, 300, paint);
            }
        }
    }
}
